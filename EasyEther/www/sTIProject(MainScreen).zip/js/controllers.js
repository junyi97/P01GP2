angular.module('app.controllers', [])
  
.controller('loginPageCtrl', function($scope) {

})
   
.controller('forgetPasswordCtrl', function($scope) {

})
   
.controller('forgetPassword2Ctrl', function($scope) {

})
   
.controller('signUpCtrl', function($scope) {

})
   
.controller('signUpSuccessfulCtrl', function($scope) {

})
   
.controller('homePageCtrl', function($scope) {

})
   
.controller('viewMyProfileCtrl', function($scope) {

})
   
.controller('automationPaymentCtrl', function($scope) {

})
   
.controller('automationPaymentConfirmedCtrl', function($scope) {

})
   
.controller('paymentCtrl', function($scope) {

})
   
.controller('paymentConfirmationCtrl', function($scope) {

})
   
.controller('automationConfirmationCtrl', function($scope) {

})
   
.controller('topUpConfirmationCtrl', function($scope) {

})
   
.controller('paymentConfirmedCtrl', function($scope) {

})
   
.controller('topUpConfirmedCtrl', function($scope) {

})
   
.controller('purchaseEtherCurrencyCtrl', function($scope) {

})
   
.controller('currentMonthBillPageCtrl', function($scope) {

})
   
.controller('pastTransactionPageCtrl', function($scope) {

})
   
.controller('pastTransactionPage1Ctrl', function($scope) {

})
   
.controller('pastTransactionPage2Ctrl', function($scope) {

})
   
.controller('pastTransactionPage3Ctrl', function($scope) {

})
   
.controller('pastTransactionPage4Ctrl', function($scope) {

})
   
.controller('setCalendarReminderCtrl', function($scope) {

})
 